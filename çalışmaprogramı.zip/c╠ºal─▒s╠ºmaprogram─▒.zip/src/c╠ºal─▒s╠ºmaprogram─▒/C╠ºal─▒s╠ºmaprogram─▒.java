
package çalışmaprogramı;

import java.util.Scanner;


public class Çalışmaprogramı {

   
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);  // scanner değerini import ediniz.
        System.out.println("--Ders Programına bakmak için gün giriniz.--");
        String girilengün = input.next();
     
        
        
        
        
        
  String gun = "Pazartesi";
  switch (gun) {
      case "Pazartesi":
          System.out.println("-Bugün yapılacaklar-");
          System.out.println("----------------");
          System.out.println("Çalışmam 1");
          System.out.println("Çalışmam 2");
          System.out.println("Çalışmam 3");
          System.out.println("Çalışmam 4");
       break;
      case "Salı":
          System.out.println("-bugün yapılacaklar-");
          System.out.println("-----------------");
          System.out.println("Çalışmam 1");
          System.out.println("Çalışmam 2");
          System.out.println("Çalışmam 3");
          System.out.println("Çalışmam 4");
          break;
      case "Çarşamba":
          System.out.println("-Bugün yapılacaklar-");
          System.out.println("-----------------");
         System.out.println("Çalışmam 1");
          System.out.println("Çalışmam 2");
          System.out.println("Çalışmam 3");
          System.out.println("Çalışmam 4");
          break;
      case "Perşembe":
          System.out.println("-Bugün yapılacaklar-");
          System.out.println("------------------");
          System.out.println("Çalışmam 1");
          System.out.println("Çalışmam 2");
          System.out.println("Çalışmam 3");
          System.out.println("Çalışmam 4");
          break;
      case "Cuma":
          System.out.println("-Bugün yapılacaklar-");
          System.out.println("-----------------");
         System.out.println("Çalışmam 1");
          System.out.println("Çalışmam 2");
          System.out.println("Çalışmam 3");
          System.out.println("Çalışmam 4");
          break;
          
      default:
          System.out.println("-Bugün yapılacaklar-");
          System.out.println("-----------------");
          System.out.println("Çalışmam 1");
          System.out.println("Çalışmam 2");
          System.out.println("Çalışmam 3");
          System.out.println("Çalışmam 4");
          
          
      
      
  }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
